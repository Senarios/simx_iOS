//
//  CreateStreamOfflineVC.swift
//  SimX
//
//  Created by APPLE on 07/07/2020.
//  Copyright © 2020 Agilio. All rights reserved.
//

import UIKit
import AVKit
import Toaster
import Alamofire

import MBProgressHUD
import AWSS3

class CreateStreamOfflineVC: UIViewController {

    
    @IBOutlet weak var myScrollView: UIScrollView!
    @IBOutlet weak var imgCheckbox: UIImageView!
    @IBOutlet weak var btnAddTags: UIButton!
    @IBOutlet weak var viewTagsOuter: UIView!
    @IBOutlet weak var tfTags: UITextField!
    @IBOutlet weak var viewAddTags: UIView!
    @IBOutlet weak var btnShowTagsView: UIButton!
    @IBOutlet weak var viewTags: UIView!
    
    @IBOutlet weak var btnUploadOfflinePitch: UIButton!
    @IBOutlet weak var btnAddVideo: UIButton!
    @IBOutlet weak var tfPitchTitle: UITextField!
    //@IBOutlet weak var viewPitchTitle: UIView!
    @IBOutlet weak var imgSelectedVideo: UIImageView!
    
    
//    @IBOutlet weak var tfJobURL: UITextField!
//    @IBOutlet weak var viewJobURL: UIView! {
//        didSet {
//            viewJobURL.isHidden = true
//        }
//    }
    
//    @IBOutlet weak var imgIsJob: UIImageView!
//    @IBOutlet weak var btnIsJob: UIButton!
//    @IBOutlet weak var lblIsJob: UILabel!
    
    @IBOutlet weak var selectLocBtn: UIButton!
    
    @IBAction func selectLocBtn(_ sender: Any) {
    }
    
    var isJobSelected: Bool = false
    var nameForVideo = ""
    var broadcastID = ""
    
    var imagePickerController = UIImagePickerController()
    var videoURL : NSURL?
    var mp4VideoURL = URL(fileURLWithPath: "")
    var selectedVideoPath: String = ""
    var tagsCollection: [String] = []
    
    let locationManager = CLLocationManager()
    
    var myLatitued = 0.0
    var myLongitude = 0.0
    var callDone: Bool = false
    
    var videoObject = COVideo()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        myScrollView.bounces = false
        self.setUpControls()
        self.setUpLocationManager()
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
//            self.imageCreatationAPI(videoName: "LfMmJB-Lmj16305389375044")
//        })
        
    }
    
    func setUpControls()
    {
        self.btnAddVideo.imageView?.contentMode = .scaleAspectFit
        self.btnAddVideo.layer.cornerRadius = 18
        self.btnAddVideo.layer.borderWidth = 1
        self.btnAddVideo.layer.borderColor = UIColor.green.cgColor
        
//        self.viewPitchTitle.layer.cornerRadius = 10
//        self.viewPitchTitle.layer.borderWidth = 1
//        self.viewPitchTitle.layer.borderColor = UIColor.lightGray.cgColor
//        self.viewPitchTitle.backgroundColor = .white
        
//        self.viewJobURL.layer.cornerRadius = 10
//        self.viewJobURL.layer.borderWidth = 1
//        self.viewJobURL.layer.borderColor = UIColor.lightGray.cgColor
//        self.viewJobURL.backgroundColor = .white
        
//        self.viewTagsOuter.layer.cornerRadius = 10
//        self.viewTagsOuter.layer.borderWidth = 1
//        self.viewTagsOuter.layer.borderColor = UIColor.lightGray.cgColor
//        self.viewTagsOuter.backgroundColor = .white
        
        self.btnAddTags.layer.cornerRadius = 15
        //self.btnShowTagsView.layer.cornerRadius = 14
        
        self.btnUploadOfflinePitch.layer.cornerRadius = 21
        self.viewAddTags.backgroundColor = UIColor(red: CGFloat(0.0/255.0), green: CGFloat(0.0/255.0), blue: CGFloat(0.0/255.0), alpha: CGFloat(0.5))
        
        let gesture = UITapGestureRecognizer(target: self, action:  #selector(self.CloseTagsView))
        gesture.delegate = self
        self.viewAddTags.addGestureRecognizer(gesture)
            
        self.viewAddTags.isHidden = true
        self.viewTags.backgroundColor = .clear
        
        self.tfTags.delegate = self
        self.tfPitchTitle.delegate = self
        
//        if (CurrentUser.Current_UserObject.skills == Constants.userSkillsType.freelancer) {
//            self.imgIsJob.isHidden = true
//            self.btnIsJob.isHidden = true
//            self.lblIsJob.isHidden = true
//        }
    }
    

    @objc func CloseTagsView(sender : UITapGestureRecognizer) {
        // Do what you want
        
        self.viewAddTags.isHidden = true
    }
    
    @IBAction func backClicked(_ sender: Any) {
        self.closeView()
    }
    
    @IBAction func addVideoClicked(_ sender: Any) {
        imagePickerController.sourceType = .savedPhotosAlbum
        imagePickerController.delegate = self
        imagePickerController.mediaTypes = [kUTTypeMovie as String]
        imagePickerController.allowsEditing = true
        present(imagePickerController, animated: true, completion: nil)
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        .black
    }
    
    @IBAction func addTagClicked(_ sender: Any) {
        
        if self.tfTags.text!.count > 0 && self.tfTags.text!.count < 12 {
            
            if tagsCollection.contains(self.tfTags.text!) {
                return
            }
            
            self.viewTags.subviews.forEach({$0.removeFromSuperview()})
            print(self.tfTags.text!)
            
            self.tagsCollection.append(self.tfTags.text!)
            self.viewAddTags.isHidden = true
            self.tfTags.text = ""
            
            var lTags = [String]()
            for tag in self.tagsCollection {
                let ltagExist = lTags.filter { $0 == tag }
                if ltagExist.count == 0 {
                    lTags.append(tag)
                }
            }
            let tags = lTags.map { button(with: $0) }
            tags.forEach({$0.addTarget(self, action: #selector(removeTag(_:)), for: .touchUpInside)})
            let frame = CGRect(x: 0, y: 0, width: self.viewTags.frame.width, height: self.viewTags.frame.height)
            let tagsView = TagsView(frame: frame)
            tagsView.backgroundColor = .none
            tagsView.create(cloud: tags)
            self.viewTags.addSubview(tagsView)
            
//            let tagsView = TagsView()
//            self.viewTags.addSubview(tagsView.reloadTagsView(with: tagsCollection, selector: #selector(self.removeTag(_:)), parentView: self.viewTags, sss: self))
        }
        else
        {
            self.showAlert("Alert", message: "Tag length must be less than 12")
        }
    }
    
    @objc func removeTag(_ sender: UIButton) {
        
        print(sender.titleLabel?.text ?? "", "Tapped")
        self.tagsCollection.removeAll(where: {$0 == sender.titleLabel?.text})
//        sender.removeFromSuperview()
        
        self.viewTags.subviews.forEach({$0.removeFromSuperview()})
        var lTags = [String]()
        for tag in self.tagsCollection {
            let ltagExist = lTags.filter { $0 == tag }
            if ltagExist.count == 0 {
                lTags.append(tag)
            }
        }
        let tags = lTags.map { button(with: $0) }
        tags.forEach({$0.addTarget(self, action: #selector(removeTag(_:)), for: .touchUpInside)})
        let frame = CGRect(x: 0, y: 0, width: self.viewTags.frame.width, height: self.viewTags.frame.height)
        let tagsView = TagsView(frame: frame)
        tagsView.backgroundColor = .none
        tagsView.create(cloud: tags)
        self.viewTags.addSubview(tagsView)
//        let tagsView = TagsView()
//        self.viewTags.addSubview(tagsView.reloadTagsView(with: tagsCollection, selector: #selector(removeTag(_:)), parentView: self.viewTags, sss: self))
    }
    
    @IBAction func jobCheckboxClicked(_ sender: Any) {
        self.isJobSelected = !self.isJobSelected
        self.imgCheckbox.image = self.isJobSelected ? UIImage(named: "checkbox") : UIImage(named: "checkbox_empty")
        self.viewJobURL.isHidden = !self.isJobSelected
    }
    
    @IBAction func showTagsViewClicked(_ sender: Any) {
        
        if self.tagsCollection.count > 4 {
            return
        }
        
        self.tfTags.becomeFirstResponder()
        self.viewAddTags.isHidden = false
    }
    
    @IBAction func playSelectedVideoClicked(_ sender: Any) {
        if self.selectedVideoPath.count > 5 {
            self.playThisVideoInAVPlayer(videoFileURLString: self.selectedVideoPath)
        }
    }
    
    
    
    func UploadPitch(){
        self.callDone = false
        DispatchQueue.main.async {
            self.videoObject.title = self.tfPitchTitle.text!
        }
        self.nameForNewStreamVideoObject()
        DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated: true)
        }
        
        self.encodeVideoToMP4(at: self.videoURL as! URL, completionHandler: { url, error in
            print("encodeVideoToMP4 completed")
            if let url = url {
                self.mp4VideoURL = url
                self.AWSS3TransferUtilityUploadFunction(with: self.nameForVideo , type: "mp4")
            }
            print(error)
            if let error = error {
                  // handle error
            }
        })
    }
    
    func nameForNewStreamVideoObject() {
        var ticks = NSDate().timeIntervalSince1970
        ticks = ticks * 10000
        let nameForNewVideo = String(format: "%10.0f", ticks)
        let uniqueVideoName = nameForNewVideo
        self.nameForVideo = CurrentUser.Current_UserObject.username + uniqueVideoName
    }
    
    func closeView() {
          self.navigationController?.popViewController(animated: true)
       // self.dismiss(animated: true, completion: nil)
    }
    
    func playThisVideoInAVPlayer(videoFileURLString: String) {
            
        print("about to launch Player with : \(videoFileURLString)")
        let url = URL(string: videoFileURLString)
        let asset = AVURLAsset(url: url!)
        let playerItem = AVPlayerItem(asset: asset)
        let player = AVPlayer(playerItem: playerItem)

        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        player.play()
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
//        // to overcome .stalled state
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
//            playerViewController.player!.play()
//        })
    }
    
    @IBAction func uploadOfflinePitchClicked(_ sender: Any) {
        if (!self.checkTitleValidity()) {
            return
        }
        
        let refreshAlert = UIAlertController(title: "Confirmation", message: "You really want to upload this video?", preferredStyle: UIAlertControllerStyle.alert)

        refreshAlert.addAction(UIAlertAction(title: "LETS GO!", style: .default, handler: { (action: UIAlertAction!) in
            print("Handle Yes Logic here")
            self.UploadPitch()
          }))

        refreshAlert.addAction(UIAlertAction(title: "NAAH", style: .cancel, handler: { (action: UIAlertAction!) in
          print("Handle No Logic here")
            
          }))

        self.present(refreshAlert, animated: true, completion: nil)
    }
    
    func checkTitleValidity() -> Bool {
        
        if(self.isJobSelected)
        {
            if(!self.isValidUrl(url: self.tfJobURL.text!))
            {
                self.showAlert("URL", message: "Entered url is invalid")
                return false
            }
        }
        
        if (self.tfPitchTitle.text == nil || self.tfPitchTitle.text == "") {
            
            self.showAlert("Alert", message: "Please put a title for new broadcast.")
            return false
        }
        else if ((self.tfPitchTitle.text?.count)! < 3) {
            self.showAlert("Title Strength", message: "Too short.")
            return false
        }
        else if (tagsCollection.count == 0) {
            self.showAlert("Tags missing", message: "Please add some tags")
            return false
        }
        else if (self.selectedVideoPath.count < 10) {
            self.showAlert("Video missing", message: "Please select video")
            return false
        }
        else {
            //self.titleTextContainer.isHidden = true
            return true
        }
        
    }
    
    func isValidUrl(url: String) -> Bool {
        let urlRegEx = "^(https?://)?(www\\.)?([-a-z0-9]{1,63}\\.)*?[a-z0-9][-a-z0-9]{0,61}[a-z0-9]\\.[a-z]{2,6}(/[-\\w@\\+\\.~#\\?&/=%]*)?$"
        let urlTest = NSPredicate(format:"SELF MATCHES %@", urlRegEx)
        let result = urlTest.evaluate(with: url)
        return result
    }
    
    func showAlert(_ title:String, message:String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(action)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    let bucketName = "simx/offlineVideos"
    var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
    
    func AWSS3TransferUtilityUploadFunction(with resource: String, type: String){
        
        let key = "\(resource).\(type)"
      //  let localImagePath = Bundle.main.path(forResource: resource, ofType: type)!  //2
      //  let localImageUrl = URL(fileURLWithPath: localImagePath)
        print("Video Key", key)
        
        let expression  = AWSS3TransferUtilityUploadExpression()
        expression.progressBlock = { (task: AWSS3TransferUtilityTask,progress: Progress) -> Void in
            print(progress.fractionCompleted)
            //do any changes once the upload is finished here
            if progress.isFinished{
                print("Upload Finished...")
                if !self.callDone{
                    self.callDone = true
                    self.addNewStreamVideoObject()
                }
            }
        }
         
        expression.setValue("public-read-write", forRequestHeader: "x-amz-acl")
        expression.setValue("public-read-write", forRequestParameter: "x-amz-acl")

        completionHandler = { (task:AWSS3TransferUtilityUploadTask, error:NSError?) -> Void in
            if(error != nil){
                print("Failure uploading file")
                
            }else{
                print("Success uploading file")
            }
        } as? AWSS3TransferUtilityUploadCompletionHandlerBlock
       
        let filePath = self.mp4VideoURL.path
        if FileManager.default.fileExists(atPath: filePath) {
            if let fileData = FileManager.default.contents(atPath: filePath) {
                // process the file data
                print("Data avilable :", fileData.count)
                AWSS3TransferUtility.default().uploadData(fileData, bucket: bucketName, key: String(key), contentType: resource, expression: expression, completionHandler: self.completionHandler).continueWith(block: { (task:AWSTask) -> AnyObject? in
                    if(task.error != nil){
                        print("Error uploading file: \(String(describing: task.error?.localizedDescription))")
                    }
                    if(task.result != nil){
                        print("Starting upload...")
                    }
                    return nil
                })
            } else {
                print("Could not parse the file")
            }
        } else {
            print("File not exists")
        }
    }
    
    // Encode video from .mov to .mp4
    func encodeVideoToMP4(at videoURL: URL, completionHandler: ((URL?, Error?) -> Void)?)  {
        let avAsset = AVURLAsset(url: videoURL, options: nil)

        let startDate = Date()

        //Create Export session
        guard let exportSession = AVAssetExportSession(asset: avAsset, presetName: AVAssetExportPresetPassthrough) else {
            completionHandler?(nil, nil)
            return
        }

        //Creating temp path to save the converted video
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] as URL
        let filePath = documentsDirectory.appendingPathComponent("rendered-Video.mp4")

        //Check if the file already exists then remove the previous file
        if FileManager.default.fileExists(atPath: filePath.path) {
            do {
                try FileManager.default.removeItem(at: filePath)
            } catch {
                completionHandler?(nil, error)
            }
        }

        exportSession.outputURL = filePath
        exportSession.outputFileType = AVFileType.mp4
        exportSession.shouldOptimizeForNetworkUse = true
        let start = CMTimeMakeWithSeconds(0.0, 0)
        let range = CMTimeRangeMake(start, avAsset.duration)
        exportSession.timeRange = range

        exportSession.exportAsynchronously(completionHandler: {() -> Void in
            switch exportSession.status {
            case .failed:
                print(exportSession.error ?? "NO ERROR")
                completionHandler?(nil, exportSession.error)
            case .cancelled:
                print("Export canceled")
                completionHandler?(nil, nil)
            case .completed:
                //Video conversion finished
                let endDate = Date()

                let time = endDate.timeIntervalSince(startDate)
                print(time)
                print("Successful!")
                print(exportSession.outputURL ?? "NO OUTPUT URL")
                completionHandler?(exportSession.outputURL, nil)

                default: break
            }

        })
    }
    
    // UPload image thumbnail
    func addNewStreamVideoObject() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
           // self.postThumbNailImage(imageData: self.imgSelectedVideo.image!)
            //broadcastID =
            self.imageCreatationAPI(videoName: self.nameForVideo)
        }
        Constants.UserData.lastBroadcastId = self.nameForVideo
        
        DispatchQueue.main.async {
            self.videoObject.jobDescriptionURL = self.tfJobURL.text!
        }
        
        videoObject.name = CurrentUser.Current_UserObject.name
        videoObject.broadcast = self.nameForVideo
        videoObject.arn = ""
        videoObject.imglink = self.nameForVideo
        videoObject.status = Constants.VideoStatus.offline
        videoObject.viewers = 0
        videoObject.time = Date().today() //"2017-05-17 09:11:47"
        videoObject.skill = CurrentUser.Current_UserObject.skills //"abc"
        videoObject.isJob = self.isJobSelected
        videoObject.latti = "\(myLatitued)" //"22.00"
        videoObject.longi = "\(myLongitude)" //"74.00"
        videoObject.username = CurrentUser.Current_UserObject.username
        videoObject.isOffline = true
        var tagsData: [Tag] = []
        for tag in tagsCollection {
            let lTag = Tag()
            lTag.tag = tag
            lTag.broadcast = self.nameForVideo
            tagsData.append(lTag)
        }
        videoObject.broadcastTags = tagsData
     //   videoObject.location = ""
        
        //videoObject.asJSON()
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            let shSingeltonObject = DataAccess.sharedInstance
            shSingeltonObject.addOrUpdateVideo(self.videoObject, delegate: self as AddUpdateVideo_Protocol)
        }
    }
    
    
    func postThumbNailImage(imageData: UIImage) {
        
        //let imageData = self.convert(cmage: image)
        let image_data = self.compressImage(imageData)
        let image : String = (image_data.base64EncodedString())
      //  var name : String = "abc" + self.nameForVideo
        var name : String = self.nameForVideo
        let videoLink : String = "https://simx.s3-us-west-2.amazonaws.com/offlineVideos/\(self.nameForVideo).mp4"
        name = name + ".png"
        
     //   uploadImage(url:Constants.API_URLs.uploadThumbnailAPI_URL, withParams:["base64": image , "ImageName" : name ])
        uploadImage(url:Constants.API_URLs.uploadVideoThumbnailAPI_URL, withParams:["videoLink": videoLink , "imageName" : name ])
        {
            (succeeded: Bool, msg: String?) -> () in
            if succeeded == true
            {
                if msg == nil
                {
                    DispatchQueue.main.async {
                        print("Uploading Failed")
                    }
                    print("\n\nMessage is nil ::: \(String(describing: msg))")
                }
                else
                {
                    // SwiftSpinner.hide()
                    DispatchQueue.main.async {
                        print("Image Uploaded")
                    }
                    print("\n\nMessage is ::: \(String(describing: msg))")
                }
            }
            else
            {
                print("Uploading Failed")
                print("\n\nError fetching Data !!!")
            }
        }
    }
    
    func uploadImage(url:String, withParams params: [String : String?] , postCompleted : @escaping (_ succeeded: Bool, _ msg: String?) -> ())
    {
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        let session = URLSession.shared
        request.httpMethod = "POST"
        var bodyData = ""
        for (key,value) in params
        {
            if (value == nil){ continue }
            let scapedKey = key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            let scapedValue = value?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            bodyData += "\(scapedKey!)=\(scapedValue!)&"
        }
        request.httpBody = bodyData.data(using: String.Encoding.utf8, allowLossyConversion: true)
        let task = session.dataTask(with: request as URLRequest, completionHandler: {data, response, error -> Void in
            
            if data != nil
            {
                print("\n\ndata is ::: \(data.debugDescription).\n\nresponse is \(response?.debugDescription ?? "nothing found in response 555")")
                let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                postCompleted(true, dataString! as String)
            }
            else
            {
                //Alert.showOfflineAlert()
                print("\n\nERROR !!! NO INTERNET CONNECTION...DATA IS NIL")
            }
        })
        task.resume()
    }
    
    func imageCreatationAPI(videoName: String){
        var name : String = videoName
        let videoLink : String = "https://simx.s3-us-west-2.amazonaws.com/offlineVideos/\(videoName).mp4"
        // let videoLink : String = "https://simx.s3-us-west-2.amazonaws.com/offlineVideos/_fZj2Zds8J15943515249107.mp4"

        let parameters = [
            "imageName": name,
            "videoLink": videoLink
        ]
        print(Constants.API_URLs.uploadVideoThumbnailAPI_URL)
        print(parameters)
        Alamofire.upload(multipartFormData: { multipartFormData in
                //loop this "multipartFormData" and make the key as array data
            
            for (key, value) in parameters {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
            } //Optional for extra parameters
        },
        to: Constants.API_URLs.uploadVideoThumbnailAPI_URL)
        { (result) in
            switch result {
            case .success(let upload, _, _):

                upload.uploadProgress(closure: { (progress) in
                 //   print("Upload Progress: \(progress.fractionCompleted)")
                })
                
                upload.responseString{ response in
                print("response.result.value")
                    let JsonResponseData = response.result.value
                    print(response.result.value)
                }
            case .failure(let encodingError):
                print(encodingError)
            }
        }// End
    }
    
    func convert(cmage:CIImage) -> UIImage
    {
        let context:CIContext = CIContext.init(options: nil)
        let cgImage:CGImage = context.createCGImage(cmage, from: cmage.extent)!
        let image:UIImage = UIImage.init(cgImage: cgImage)
        return image
    }
    
    func compressImage (_ image: UIImage) -> Data {
        
        let compressionQuality:CGFloat = 0.5
        
        let rect:CGRect = CGRect(x: 0, y: 0, width: 100, height: 80)
        UIGraphicsBeginImageContext(rect.size)
        image.draw(in: rect)
        let img: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        let imageData:Data = UIImageJPEGRepresentation(img, compressionQuality)!//! as Data
        return imageData
    }

}
extension CreateStreamOfflineVC {
    
    func button(with title: String) -> UIButton {
        var font = UIFont.preferredFont(forTextStyle: .body)
       // [UIFont boldSystemFontOfSize:13.f]
        font = font.withSize(11)
        let attributes: [NSAttributedString.Key: Any] = [.font: font]
        let size = title.size(withAttributes: attributes)
        
        let button = UIButton(type: .custom)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = font
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = (size.height + 10.0 ) / 2
        button.backgroundColor = UIColor(red: CGFloat(10.0/255.0), green: CGFloat(73.0/255.0), blue: CGFloat(122.0/255.0), alpha: CGFloat(1.0))
        button.frame = CGRect(x: 10.0, y: 0.0, width: size.width + 20.0, height: size.height + 10.0)
        button.titleEdgeInsets = UIEdgeInsets(top: 0.0, left: 5.0, bottom: 0.0, right: 5.0)
        return button
    }
}

extension CreateStreamOfflineVC: UIGestureRecognizerDelegate{
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return gestureRecognizer.view === touch.view
    }
}

extension CreateStreamOfflineVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        videoURL = info[UIImagePickerControllerMediaURL] as? URL as NSURL?
        
        self.selectedVideoPath = self.videoURL?.absoluteString as! String
        print("videoURL:\(String(describing: videoURL))", self.selectedVideoPath)
        do {
            let asset = AVURLAsset(url: videoURL as! URL , options: nil)
            let imgGenerator = AVAssetImageGenerator(asset: asset)
            imgGenerator.appliesPreferredTrackTransform = true
            let cgImage = try imgGenerator.copyCGImage(at: CMTimeMake(0, 1), actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            self.imgSelectedVideo.image = thumbnail
        } catch let error {
            print("*** Error generating thumbnail: \(error.localizedDescription)")
        }
        self.dismiss(animated: true, completion: nil)
    }
}
extension CreateStreamOfflineVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == tfTags || textField == tfPitchTitle {
            textField.resignFirstResponder()
            return false
        }
        return true
    }
}

extension CreateStreamOfflineVC: AddUpdateVideo_Protocol {
    func updatedResponse(isSuccess: Bool , error: String, id: Int)
    {
        print("Broadcast created with", id)
        //DispatchQueue.main.async {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            let messageToast = Toast(text: "New Broadcast created", duration: Delay.short)
            messageToast.show()
            
            MBProgressHUD.hide(for: self.view, animated: true)
            //self.nameForVideo
            self.imageCreatationAPI(videoName: self.nameForVideo)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.closeView()
            }
        }
    }
}

extension CreateStreamOfflineVC: CLLocationManagerDelegate {
    func setUpLocationManager() {
            
//        // Ask for Authorisation from the User.
//        self.locationManager.requestAlwaysAuthorization()
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        myLatitued  = locValue.latitude
        myLongitude = locValue.longitude
        locationManager.stopUpdatingLocation()
        
        let longitude :CLLocationDegrees = myLongitude
        let latitude :CLLocationDegrees = myLatitued
        
        self.videoObject.longi = "\(myLongitude)"
        self.videoObject.latti = "\(myLatitued)"
        
        let location = CLLocation(latitude: latitude, longitude: longitude) //changed!!!
        print(location)
        
        CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) -> Void in
            print(location)
            
            if error != nil {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks![0]
                var countryString = "not found"
                if (pm.country != nil) {
                    countryString = pm.country!
                }
                self.videoObject.location = "\(pm.locality ?? "") \(pm.subLocality ?? ""),\(countryString)"
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })
    }
}
